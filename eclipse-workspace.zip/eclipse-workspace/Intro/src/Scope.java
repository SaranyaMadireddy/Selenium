import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Scope {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		System.out.println(driver.findElements(By.tagName("a")).size());
		
		WebElement footer=driver.findElement(By.id("gf-BIG"));  //limiting webdriver scope
		System.out.println(footer.findElements(By.tagName("a")).size());
		WebElement test=footer.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));
		Integer count=test.findElements(By.tagName("a")).size();
		List<WebElement> count1=test.findElements(By.tagName("a"));
		
		for(int i=1;i<count;i++)
		{
			
			String clicklink=Keys.chord(Keys.CONTROL,Keys.ENTER);
			count1.get(i).sendKeys(clicklink);
			Thread.sleep(5000);
			
		}
			Set<String> window=driver.getWindowHandles();
			Iterator<String> it=window.iterator();
			
			while(it.hasNext())
			{
			driver.switchTo().window(it.next());
			System.out.println(driver.getTitle());
			}
		
		}
		
		
	}
	
	


