import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PracticeSection7 {

	public static void main(String[] args) {

		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		WebElement checkbox=driver.findElement(By.id("checkBoxOption1"));
		
		checkbox.click();
		System.out.println(checkbox.isSelected());
		checkbox.click();
		System.out.println(checkbox.isSelected());
		
		List<WebElement> totalcheckboxes=driver.findElements(By.cssSelector("input[type='checkbox']"));
		
		System.out.println(totalcheckboxes.size());
		
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		
		driver.findElement(By.name("name")).sendKeys("Sharu");
		
		driver.findElement(By.cssSelector("input[name='email']")).sendKeys("test.@t.com");
		
		driver.findElement(By.id("exampleInputPassword1")).sendKeys("test123");
		
		driver.findElement(By.id("exampleCheck1")).click();
		
		WebElement dropdown=driver.findElement(By.id("exampleFormControlSelect1"));
		
		Select d=new Select(dropdown);
		d.selectByVisibleText("Female");
		
		driver.findElement(By.id("inlineRadio1")).click();
		
		driver.findElement(By.name("bday")).sendKeys("05/24/1995");
		
		driver.findElement(By.cssSelector("input[type='submit']")).click();
		
		System.out.println(driver.findElement(By.cssSelector("div[class*='alert-success']")).getText());
		

	}

}
