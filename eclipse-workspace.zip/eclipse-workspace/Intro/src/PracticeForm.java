import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class PracticeForm {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/angularpractice/");
		
		driver.findElement(By.name("name")).sendKeys("Sharu");
		driver.findElement(By.name("email")).sendKeys("test@t.com");
		driver.findElement(By.id("exampleInputPassword1")).sendKeys("test@1");
		driver.findElement(By.id("exampleCheck1")).click();
		WebElement test=driver.findElement(By.id("exampleFormControlSelect1"));
		Select test1=new Select(test);
		test1.selectByVisibleText("Female");
		driver.findElement(By.id("inlineRadio1")).click();
		driver.findElement(By.xpath("//input[@type='date']")).sendKeys("24/05/1995");
		driver.findElement(By.xpath("//*[@type='submit']")).click();
		System.out.println(driver.findElement(By.cssSelector("div[class*='alert-success']")).getText());
	}

}
