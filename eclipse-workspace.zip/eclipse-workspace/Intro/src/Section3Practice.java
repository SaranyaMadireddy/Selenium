
public class Section3Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] number= {1,2,3,4,5};
		 
		System.out.println(number[0]);
		
		System.out.println(number[4]);
		
		
		for(int i=4;i>=0;i--)
		{
			System.out.println(number[i]);
		}
		
		System.out.println(number.length);
		
		Section3Practice p=new Section3Practice();
		getData();
	}
	
	public static void getData()
	{
		System.out.println("Hello");
	}

}
