import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Section12Practise {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		driver.findElement(By.name("courses"));
		
		System.out.println(driver.findElements(By.xpath("//table[@name='courses']/tbody/tr")).size());
		
		
		System.out.println(driver.findElements(By.xpath("//table[@name='courses']/tbody/tr/th")).size());
		
		List<WebElement> rowtext=driver.findElements(By.xpath("//table[@name='courses']/tbody/tr[3]/td"));
		
		for(int i=0;i<rowtext.size();i++)
		{
			System.out.println(rowtext.get(i).getText());
		}
		
	}

}
