import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PracticePage {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");

		// Radio Button
		driver.findElement(By.cssSelector("input[value='radio2']")).click();

		// autosuggestive dropdown
		driver.findElement(By.id("autocomplete")).sendKeys("ind");

		List<WebElement> test = driver.findElements(By.cssSelector(".ui-menu-item-wrapper"));

		for (int i = 0; i < test.size(); i++) {

			if (test.get(i).getText().equals("India")) {
				test.get(i).click();
			} else {
				System.out.println("not india");
			}
		}

		// static Drop down
		WebElement dropdown = driver.findElement(By.id("dropdown-class-example"));

		Select d = new Select(dropdown);
		d.selectByValue("option1");

		// dynamic dropdown
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		driver.findElement(By.cssSelector("input[id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		driver.findElement(By.cssSelector("a[value='MAA']")).click();
		driver.findElement(By.cssSelector("div[id='glsctl00_mainContent_ddl_destinationStation1_CTNR'] a[value='CJB']"))
				.click();

		// CheckBox

		driver.findElement(By.id("checkBoxOption3")).click();

		// Windows
		driver.findElement(By.id("openwindow")).click();

		Set<String> window = driver.getWindowHandles();
		Iterator<String> it = window.iterator();
		String Parentid = it.next();
		String childid = it.next();
		driver.switchTo().window(childid);
		System.out.println(driver.findElement(By.cssSelector(".cont")).getText());
		driver.switchTo().window(Parentid);

		// Switch tab

		driver.findElement(By.id("opentab")).click();

		Set<String> tab = driver.getWindowHandles();
		Iterator<String> newtab = tab.iterator();
		String Parenttab = newtab.next();
		String Childtab = newtab.next();
		driver.switchTo().window(Childtab);
		driver.findElement(By.xpath("//a[text()='Access all our Courses']")).click();
		driver.switchTo().window(Parenttab);

		// Alert
		driver.findElement(By.id("name")).sendKeys("Sharu");
		driver.findElement(By.id("alertbtn")).click();
		System.out.println(driver.switchTo().alert().getText().split(",")[0].split(" ")[1]);
		driver.switchTo().alert().accept();

		// Display or Hide Element
		driver.findElement(By.id("hide-textbox")).click();
		driver.findElement(By.id("show-textbox")).click();
		System.out.println(driver.findElement(By.id("displayed-text")).isDisplayed());

		// Mouse hover
		Actions a = new Actions(driver);

		a.moveToElement(driver.findElement(By.id("mousehover"))).build().perform();
		a.moveToElement(driver.findElement(By.xpath("//a[@href='#top']"))).click().build().perform();
		a.moveToElement(driver.findElement(By.id("mousehover"))).build().perform();
		a.moveToElement(driver.findElement(By.linkText("Reload"))).click().build().perform();

		// Frames
		driver.switchTo().frame(driver.findElement(By.id("courses-iframe")));
		driver.findElement(By.linkText("Courses")).click();
		driver.switchTo().defaultContent();
		
		WebDriverWait w=new WebDriverWait(driver, Duration.ofSeconds(5));
		w.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Courses")));

	}

}
