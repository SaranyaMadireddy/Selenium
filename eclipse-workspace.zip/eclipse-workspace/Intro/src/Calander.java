import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class Calander {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		driver.findElement(By.linkText("Top Deals")).click();
		
		Set<String> deals=driver.getWindowHandles();
		Iterator<String> it=deals.iterator();
		String parentid=it.next();
		String childid=it.next();
		driver.switchTo().window(childid);
		driver.findElement(By.cssSelector("div[class='react-date-picker__inputGroup']")).click();
		String monthNumber="5";
		String date="24";
		String year="2025";
		String[] expectedvalue= {monthNumber,date,year};
		
		driver.findElement(By.cssSelector(".react-date-picker__calendar.react-date-picker__calendar--open"));
		driver.findElement(By.className("react-calendar__navigation__label")).click();
		driver.findElement(By.className("react-calendar__navigation__label")).click();
		driver.findElement(By.xpath("//button[text()='"+year+"']")).click();
		driver.findElements(By.cssSelector(".react-calendar__tile.react-calendar__year-view__months__month")).get(Integer.parseInt(monthNumber)-1).click();
		driver.findElement(By.xpath("//abbr[text()='"+date+"']")).click();
		List<WebElement> value=driver.findElements(By.cssSelector(".react-date-picker__inputGroup__input"));
		
		for(int i=0;i<value.size();i++)
		{
			System.out.println(value.get(i).getAttribute("value"));
			Assert.assertEquals(value.get(i).getAttribute("value"),expectedvalue[i]);
		}
		
		
		/*List<WebElement> yearvalue=driver.findElements(By.cssSelector("div[class='react-calendar__decade-view__years'] button"));
		
		for(int i=0;i<yearvalue.size();i++)
		{
			if(yearvalue.get(i).getText().contentEquals(year))
			{
				yearvalue.get(i).click();
				break;
			}
			
		}
		
		//driver.findElements(By.cssSelector("div[class='react-calendar__year-view__months'] button")).contains("May")
		
		List<WebElement> month=driver.findElements(By.cssSelector("div[class='react-calendar__year-view__months'] button"));
		for(int i=0;i<month.size();i++)
		{
			if(month.get(i).getText().contentEquals("May"))
			{
				month.get(i).click();
				break;
			}
			
		}
		List<WebElement> datenum=driver.findElements(By.cssSelector("div[class='react-calendar__month-view__days'] button"));
		for(int i=0;i<datenum.size();i++)
		{
			if(datenum.get(i).getText().contentEquals(date))
			{
				datenum.get(i).click();
				break;
			}
			
		}*/
		//System.out.println(driver.findElement(By.cssSelector("//div[@class='react-date-picker__inputGroup']")).getText());
		//Assert.
	}

}
