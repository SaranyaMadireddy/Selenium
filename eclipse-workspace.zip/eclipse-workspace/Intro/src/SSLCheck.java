import java.net.HttpURLConnection;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class SSLCheck {

	public static void main(String[] args) {
		
		//SSL check -private,safe
		ChromeOptions options=new ChromeOptions();
		options.setAcceptInsecureCerts(true);
		
		//Proxy
		Proxy proxy=new Proxy();
		proxy.setHttpProxy("ipaddress");
		options.setCapability("Proxy", proxy);
		
		WebDriver driver=new ChromeDriver(options);
		
		driver.get("https://expired.badssl.com/");
		

		
	}

}
