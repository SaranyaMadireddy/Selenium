import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PractiseSection9 {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://rahulshettyacademy.com/loginpagePractise/");
		driver.manage().window().maximize();
		driver.findElement(By.id("username")).sendKeys("rahulshettyacademy");
		driver.findElement(By.name("password")).sendKeys("learning");
		driver.findElement(By.cssSelector("input[value='user']")).click();	
		WebDriverWait w=new WebDriverWait(driver,Duration.ofSeconds(10));
		w.until(ExpectedConditions.visibilityOfElementLocated((By.cssSelector("button[id='okayBtn']"))));
		driver.findElement(By.cssSelector("button[id='okayBtn']")).click();
		WebElement test=driver.findElement(By.cssSelector("select[class='form-control']"));
		Select dropdown=new Select(test);
		dropdown.selectByValue("consult");
		driver.findElement(By.id("terms")).click();
		driver.findElement(By.id("signInBtn")).click();
		WebDriverWait w1=new WebDriverWait(driver,Duration.ofSeconds(5));
		w1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//app-card-list[@class='row']")));
	
		List<WebElement> products=driver.findElements(By.cssSelector(".btn-info"));
	
		
		
		for(int i=0;i<products.size();i++)
		{
			
			products.get(i).click();
			
		}
		driver.findElement(By.cssSelector(".btn-primary")).click();
	}


}
