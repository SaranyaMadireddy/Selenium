import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class Section11PracticeAss {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		driver.findElement(By.id("checkBoxOption3")).click();
		String value =driver.findElement(By.cssSelector("label[for='honda']")).getText();
		System.out.println(value);
		
		WebElement test=driver.findElement(By.id("dropdown-class-example"));
		
	Select dropdown=new Select(test);
	dropdown.selectByVisibleText(value);
	driver.findElement(By.id("name")).sendKeys(value);
	driver.findElement(By.id("alertbtn")).click();
	driver.switchTo().alert();
	Assert.assertEquals(driver.switchTo().alert().getText().split(",")[0].split(" ")[1].trim(),value);
	
	
		

	}

}
