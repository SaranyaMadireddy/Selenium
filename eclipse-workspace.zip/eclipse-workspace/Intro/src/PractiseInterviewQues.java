import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PractiseInterviewQues {

	public static void main(String[] args) {
	
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.kapruka.com/srilanka_online_shopping.jsp?d=mobile");
		
		List<WebElement> price=driver.findElements(By.className("catalogueV2converted"));
		
		System.out.println(price.get(0).getText());
		
	}

}
