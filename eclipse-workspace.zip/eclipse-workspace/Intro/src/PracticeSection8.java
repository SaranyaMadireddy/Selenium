import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeSection8 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
		String[] products= {"Brocolli","Cucumber","Beetroot"};
		
		List<WebElement> veggies=driver.findElements(By.xpath("//div[@class='product']/h4"));		
		
		Thread.sleep(2000);
		
		for(int i=0;i<veggies.size();i++)
		{
			String formattedprod=veggies.get(i).getText().split("-")[0].trim();
			
			List<String> prodlist=Arrays.asList(products);
			System.out.println(prodlist);
			
			if(prodlist.contains(formattedprod))
			{
				
				driver.findElements(By.xpath("//div[@class='product-action']/button[@type='button']")).get(i).click();
			}
		}
			
		
	}

}
