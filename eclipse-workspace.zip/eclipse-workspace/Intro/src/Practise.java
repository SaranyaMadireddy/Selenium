import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Practise {

	public static void main(String[] args) throws InterruptedException {
		
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\c45182\\OneDrive - Cox Communications\\Documents\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.get("https://practicetestautomation.com/practice-test-login/");
		/*driver.findElement(By.id("username")).sendKeys("student");
		driver.findElement(By.name("password")).sendKeys("Password123");
		driver.findElement(By.className("btn")).click();
		System.out.println(driver.getCurrentUrl());
		driver.findElement(By.className("wp-block-group")).click();*/
		
		/*driver.findElement(By.xpath("//input[@name='username']")).sendKeys("incorrectUser ");
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("Password123 ");
		driver.findElement(By.xpath("//button[@class='btn']")).click();
		Thread.sleep(5000);
		String errormsg=driver.findElement(By.xpath("//div[@id='error']")).getText();
		System.out.println(errormsg);*/
		
		
		//Section 2 Practice
		//System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\c45182\\\\OneDrive - Cox Communications\\\\Documents\\\\chromedriver-win64 (1)\\\\chromedriver-win64\\\\chromedriver.exe");
		//WebDriver driver1=new ChromeDriver();
		
		/*driver1.get("https://www.google.com");
		System.out.println(driver1.getTitle());
		System.out.println(driver1.getCurrentUrl());
		driver1.close();
		driver1.quit();*/
		
		//Section 3 Practice
		//Data Types
		/*int num =9;
		String s="Saranya";
		char c='r';
		Boolean test =true;
		double d=9.4;
		
		System.out.println(num +" this is an integer");
		System.out.println(s);
		
		//Arrays
		int[] arr=new int[5];
		arr[0]=1;
		arr[1]=2;
		arr[2]=3;
		arr[3]=4;
		arr[4]=5;
		
		int[] arr2= {1,2,3,4,5,122,344};
		System.out.println(arr2[3]);
		
		for (int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		
		for(int i=0;i<arr2.length;i++)
		{
			System.out.println(arr2[i]);
		}
				
		String[] name= {"Sharu","learn","Selenium"};
		
		for(int i=0;i<name.length;i++)
		{
			System.out.println(name[i]);
		}
		//Enhanced for loop
		for(String s1:name)
		{
			System.out.println(s1);
		}
		
		//Conditionalised loop
		for (int i=0;i<arr2.length;i++)
		{
			if(arr2[i]%2==0)
			{
				System.out.println(arr2[i]);
				break;
			}
			else
			{
				System.out.println(arr2[i] + "odd number");
			}
		}*/
		
		
		/*	int[] numbers= {1,2,3,4,5};
		
		for(int i=0;i<numbers.length;i++)
		{
			if(i ==0)
			{
				System.out.println(numbers[i]);
			}
			else if(i==4)
			{
				System.out.println(numbers[i]);
			}
		}
		
		for(int i=numbers.length-1;i>=0;i--)
		{
			System.out.println(numbers[i]);
		}
		
		System.out.println(numbers.length);
		
		ArrayList<String> a=new ArrayList<String>();
		a.add("Sharu");
		a.add("Learning");
		a.add("Selenium");
		a.remove(0);
		System.out.println(a.get(1));
		
		for(int i=0;i<a.size();i++)
		{
			System.out.println(a.get(i));
		}
		
		for( String val:a)
		{
			System.out.println(val);
		}
		
		System.out.println(a.contains("Selenium"));
		
		String[] name= {"Sharu","learn","Selenium"};
		
		List<String> names=Arrays.asList(name);
		
		System.out.println(names.contains("learn"));
		
		
		
		/*int[] arr=new int[5];
		arr[0]=1;
				
		int[] arr1={1,2,3};
		
		ArrayList<String> arr2=new ArrayList<String>();
		arr2.add("Sharu");
		//arr2.remove(0);
		System.out.println(arr2.contains("Sharu"));
		
		List<int[]> a5=Arrays.asList(arr1);
		System.out.println(a5.contains(1));
		
		//String literal
		//String s="Saranya Learning selenium";
		String s1="Saranya";
		
		//new
		String s2=new String("Movie");
		
		
		String s="Saranya Learning selenium";
		String[] Splitvar= s.split("Learning");
		System.out.println(Splitvar[0]);
		System.out.println(Splitvar[1].trim());
		
		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.println(s.charAt(i));
		}
		
		
		
		Practise p=new Practise();
		String name1=p.getdata();
		System.out.println(name1);
		p.getdata2();
		getdata3();
		
		MethodDemo2 m=new MethodDemo2();
		m.getuserdata();*/
		
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.findElement(By.id("inputUsername")).sendKeys("Sharu");
		driver.findElement(By.name("inputPassword")).sendKeys("test123");
		driver.findElement(By.className("submit")).click();
		System.out.println(driver.findElement(By.cssSelector("p.error")).getText());
		driver.findElement(By.linkText("Forgot your password?")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("Sharu");
		driver.findElement(By.cssSelector("input[placeholder='Email']")).sendKeys("test@a.com");
		driver.findElement(By.xpath("//input[@type='text'][2]")).clear();
		driver.findElement(By.cssSelector("input[type='text']:nth-child(3)")).sendKeys("test1@a.com");
		driver.findElement(By.xpath("//form/input[3]")).sendKeys("7894561230");
		driver.findElement(By.cssSelector(".reset-pwd-btn")).click();
		System.out.println(driver.findElement(By.cssSelector("form p")).getText());
		driver.findElement(By.xpath("//div[@class='forgot-pwd-btn-conainer']/button[1]")).click();
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("input#inputUsername")).sendKeys("Sharu");
		driver.findElement(By.cssSelector("input[type*='pass']")).sendKeys("rahulshettyacademy");
		driver.findElement(By.id("chkboxOne")).click();
		driver.findElement(By.xpath("//button[contains(@class,'submit')]")).click();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
	}

	/*public String getdata()
	{
		System.out.println("test");
		return "testreturn";
	}
	public void getdata2()
	{
		System.out.println("test2");
		
	}
	public static void getdata3()
	{
		System.out.println("test3");
	}*/
	
	}


