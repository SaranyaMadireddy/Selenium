
public class JavaBasics {

	public static void main(String[] args) {
		//Data Types -int,double,String,char,boolean  and Variables num,value
		int num=5;
		double value=2.4;
		String a="This is a string";
		char c ='r';
		boolean b=true;
		System.out.println(num+" This is integer value");
		System.out.println(a);
		
		//Array -Array can store multiple values of same datatype in variable
		int[] arr=new int[5];
		arr[0]=1;
		arr[1]=2;
		arr[2]=3;
		arr[3]=4;
		arr[4]=5;
		
		System.out.println(arr[3]);
		
		int[] arr2={10,20,30,40,50};
		
		System.out.println(arr2[2]);
		
		for (int i=0;i<3;i++)
		{
			System.out.println(i);
		}
		
		for (int i=0;i<arr2.length;i++)
		{
			System.out.println(arr2[i]);
		}
		
		String[] name= {"Saranya","Suman","Cute"};
		
		for(int i=0;i<name.length;i++)
		{
			System.out.println(name[i]);
		}
		
		for (String s:name)
		{
			System.out.println(s);
		}
	///////////////////////////////////////////////////
		int myNum=5;
		String website="Rahul sheety Academy";
		char letter='r';
		double dec=6.9;
		boolean mycard=true;
		
		System.out.println(myNum +"is the value stored in myNum var");
		
		//Arrays
		int[] arr1=new int[5];
		arr1[0]=1;
		arr1[1]=2;
		arr1[2]=3;
		arr1[3]=4;
		arr1[4]=5;
		
		int[] arr3= {1,2,3,4,5};
		System.out.println(arr3[2]);
		
		for (int i1=0;i1<arr3.length;i1++)
		{
			System.out.println(arr3[i1]);
		}
		
		String[] s= {"Sharu","good","Girl"};
		for (int i=0;i<s.length;i++)
		{
			System.out.println(s[i]);
		}
		for(String s1:s)
		{
			System.out.println(s1);
		}
	}

}