import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class PracticeSection11 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		/*driver.findElement(By.id("checkBoxOption2")).click();
		
		
	
		String option=driver.findElement(By.cssSelector("label[for='benz']")).getText();
		
		
		
		WebElement dropdown=driver.findElement(By.id("dropdown-class-example"));
		
		Select s=new Select(dropdown);
		
		s.selectByVisibleText(option);
		
		driver.findElement(By.cssSelector("input[id='name']")).sendKeys(option);
		
		driver.findElement(By.id("alertbtn")).click();
		
		driver.switchTo().alert();
		
		String alertmsg=driver.switchTo().alert().getText();
		
		Assert.assertEquals(alertmsg.split(",")[0].split(" ")[1].trim(), option);*/
		
		WebElement footer=driver.findElement(By.id("gf-BIG"));
		
		System.out.println(footer.findElements(By.tagName("a")).size());
		
		WebElement test=footer.findElement(By.xpath("//table/tbody/tr/td[1]/ul"));
		
		Integer links=test.findElements(By.tagName("a")).size();
		
		List<WebElement> count=test.findElements(By.tagName("a"));
		
		for(int i=0;i<links;i++)
		{
			
			String keys=Keys.chord(Keys.CONTROL,Keys.ENTER);
			
			count.get(i).sendKeys(keys);
			
			
		}

	}

}
