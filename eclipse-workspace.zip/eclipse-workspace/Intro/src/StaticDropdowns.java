import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class StaticDropdowns {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\c45182\\OneDrive - Cox Communications\\Documents\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
		WebElement Dropdown=driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
		//Static dropdowns should have select tag
		Select currency=new Select(Dropdown);
		currency.selectByIndex(1);
		System.out.println(currency.getFirstSelectedOption().getText());
		currency.selectByValue("AED");
		System.out.println(currency.getFirstSelectedOption().getText());
		currency.selectByVisibleText("USD");
		System.out.println(currency.getFirstSelectedOption().getText());

	}

}
