import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class SeleniumLearning {
	

	public static void main(String[] args) {
		//Invoking chrome browser
				//chrome -chromedriver class extern->all Methods (close ,get)
				//firefox -FirefoxDriver ->Methods close get
				//safari safariDriver ->Methods close get
				// Webdriver is an interface close get
				//WedDriver Methods+Class Methods
		//invoke chrome driver Key-value pair or selenium manager(no need of setproperty step)
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\c45182\\OneDrive - Cox Communications\\Documents\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//invoke firefox driver
		//System.setProperty("webdriver.gecko.driver", "");
		//WebDriver driver=new FirefoxDriver();
		
		//invoke Edge driver
		//System.setProperty("webdriver.edge.driver", "");
		//WebDriver driver=new EdgeDriver();
				
		driver.get("https://rahulshettyacademy.com/");
		System.out.println(driver.getTitle());
		System.out.println(driver.getCurrentUrl());
		//driver.close();
		//driver.quit();
	}

}
