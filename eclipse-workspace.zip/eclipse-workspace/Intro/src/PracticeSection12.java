import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class PracticeSection12 {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://rahulshettyacademy.com/AutomationPractice/");
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		js.executeScript("window.scrollBy(0,500)");
		
	//	js.executeScript("document.querySelector('.table-display').scrolldown=5000");
		
		System.out.println(driver.findElements(By.cssSelector("table[class=table-display] tr")).size());
		
		List<WebElement> text=driver.findElements(By.xpath("//table[@class='table-display']/tbody/tr[3]/td"));
		
		for(int i=0;i<text.size();i++)
			
		{
			System.out.println(text.get(i).getText());
		}
		
		
		WebElement dropdown=driver.findElement(By.id("autocomplete"));
		
		dropdown.sendKeys("ind");
		
		String key=Keys.chord(Keys.ARROW_DOWN,Keys.ARROW_DOWN,Keys.ARROW_DOWN,Keys.ENTER);
		
		dropdown.sendKeys(key);
		
		System.out.println(dropdown.getDomAttribute("value"));
		
		ChromeOptions op=new ChromeOptions();
		op.setAcceptInsecureCerts(true);
		
		driver.manage().window().maximize();	
		driver.manage().deleteAllCookies();
		
		driver.manage().deleteCookieNamed("abc");
		
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src,new File(".png"));
	}

}
