
public class JavaBasics3 {

	public static void main(String[] args) {
		
		//String is an Object with set of characters -String literal - s is created s1 var is not created as it has same value
		//String s="Rahul shetty Acadamy";
		String s1="Rahul shetty Acadamy";
		String s2="Rahul";  //different  value var is created
		
		//new object - 2 objects are create s2 ,s3 even if value is same
		
		String s3=new String("Rahul shetty Acadamy");
		String s4=new String("Rahul shetty Acadamy");
		
		String s="Rahul sheety Acadamy";
		String[] splitvalue=s.split("sheety");
		System.out.println(splitvalue[0]);
		System.out.println(splitvalue[1]);
		System.out.println(splitvalue[1].trim());
		
		for(int i=0;i<s.length();i++)
		{
			System.out.println(s.charAt(i));
		}
		System.out.println("***************************");
		
		for(int i=s.length()-1;i>=0;i--)
		{
			System.out.println(s.charAt(i));
		}
		
		
	}

}
