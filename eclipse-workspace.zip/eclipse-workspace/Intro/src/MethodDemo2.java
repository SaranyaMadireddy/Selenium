
public class MethodDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	//Type 3 method outside of class
	public void getdata2()
	{
		System.out.println("Hello");
	}
	
	public void getuserdata()
	{
		System.out.println("test4");
	}
}
