
public class MethodsDemo1 {

	public static void main(String[] args) {
	
		
		MethodsDemo1 m=new MethodsDemo1();
		m.getdata();
		String s= m.getdata1();
		System.out.println(s);
		MethodDemo2 m1=new MethodDemo2();
		m1.getdata2();
		getdata3();
		
	}
	//Type 1 Method  void ids used when no return type
	public void getdata()
	{
		System.out.println("Hello World");
	}
	
	//Type 2 Method with return Type
	
	public String getdata1()
	{
	System.out.println("Hello World");
	return "Sharu";
	}	
	
	//Type 4 without object using method
	public static void getdata3()
	{
		System.out.println("Hey we did it");
	}
}
