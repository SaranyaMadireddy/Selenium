import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class JavaBasics2 {

	public static void main(String[] args) {
		int[] num = {1,2,4,5,6,7,8,10};
		
		for(int i=0;i<num.length;i++)
		{
			if(num[i]%2 ==0)
			{
			System.out.println(num[i]);
			break;
			}
			
			else
			{
				System.out.println(num[i] +" Odd number");
			}
		}
		
		//Exercise
		var numbers = new int[] {1,2,8,9,5};
		
		for (int i=0;i<numbers.length;i++)
		{
			if(i==0)
			{
				System.out.println(numbers[i]);
			
			}
			else if(i==4)
			{
			System.out.println(numbers[i]);
			}
		}
		
		for(int i=4;i>=0;i--)
		{
		    System.out.println(numbers[i]);
		   
		}
			System.out.println(numbers.length);
		
			
		ArrayList<String> a=new ArrayList<String>();
		a.add("Selenium");
		a.add("Automation");
		a.add("Trending");
		//a.remove(2);
		System.out.println(a.get(1));
		
		for (int i=0;i<a.size();i++)
		{
			System.out.println(a.get(i));
		}
		for(String val:a)
		{
			System.out.println(val);
		}
		System.out.println(a.contains("Selenium"));
	
// Converting Array to Array List
	String[] s= {"Sharu","good","Girl"};
	List<String> nameArrayList=Arrays.asList(s);
	System.out.println(nameArrayList.contains("Sharu"));
}
}
