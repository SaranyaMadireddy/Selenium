import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.annotations.Test;

public class Streams {

	
		
		//@Test
		public void regular()
		{
			ArrayList<String> names=new ArrayList<String>();
			names.add("Abhi");
			names.add("Sharu");
			names.add("Akhil");
			names.add("Suman");
			int count=0;
			for(int i=0;i<names.size();i++)
			{
				String actual=names.get(i);
				if(actual.startsWith("A"))
				{
					count++;
				}
			}
			System.out.println(count);
		}
		
		@Test
		public void steams()
		{
			ArrayList<String> names=new ArrayList<String>();
			names.add("Abhi");
			names.add("Sharu");
			names.add("Akhil");
			names.add("Suman");
			
			Long d=names.stream().filter(s->s.startsWith("A")).count()	;
			System.out.println(d);
			
		}
	
		@Test
		public void map()
		{
			Stream.of("Abhi","Don","Chari","Alekhya").filter(s->s.length()>4).map(s->s.toUpperCase()).forEach(s->System.out.println(s));
			Stream.of("Abhi","Don","Chari","Alekhya").filter(s->s.length()>4).limit(1).map(s->s.toUpperCase()).forEach(s->System.out.println(s));
			
			List<String> names=Arrays.asList("Abhi","Don","Chari","Alekhya");
			
			names.stream().filter(s->s.endsWith("i")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.println(s));
			
			//Merge Lists
			List<String> names1=Arrays.asList("Abhi","Don","Chari","Alekhya");
			ArrayList<String> names2=new ArrayList<String>();
			names2.add("SUman");
			names2.add("Sharu");
			
			Stream<String> total=Stream.concat(names1.stream(), names2.stream());
			//total.filter(s->s.startsWith("S")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.println(s));
			
			total.filter(s->s.startsWith("S")).map(s->s.toUpperCase()).anyMatch(s->s.equalsIgnoreCase("Suman"));
		}	
			@Test
			
			public void collect()
			{
				List<String> ls=Stream.of("Abhi","Don","Chari","Alekhya").filter(s->s.length()>4).map(s->s.toUpperCase()).collect(Collectors.toList());
				System.out.println(ls.get(0));
				
			}
			
			@Test
			
			public void ass()
			{
				List<Integer> values=Arrays.asList(3,2,2,7,5,1,9,7);
				
				values.stream().distinct().sorted().forEach(s->System.out.println(s));
				
				List<Integer> li=values.stream().distinct().sorted().collect(Collectors.toList());
				
				li.get(2);
				
				
				
				
				
		}

}
