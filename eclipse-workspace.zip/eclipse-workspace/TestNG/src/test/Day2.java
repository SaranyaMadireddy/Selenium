package test;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class Day2 {
	
	
@Test(groups= {"Smoke"})

public void Test3()
{
	System.out.println("Home");
}

@Parameters({"url"})
@BeforeTest
public void prerequisite(String urllink)
{
	System.out.println("I will execute first");
	System.out.println(urllink);
}


}
