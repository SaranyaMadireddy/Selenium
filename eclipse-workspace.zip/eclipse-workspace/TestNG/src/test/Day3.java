package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



public class Day3 {
	
@Test(groups= {"Smoke"})

public void webLoginCarLoan()
{
	System.out.println("login carloan");
}

@Parameters({"url","username"})
@Test(timeOut=4000)
public void MobileLoginCarLoan(String url1,String username)
{
	System.out.println("Mobile carloan");
	System.out.println(url1);
	System.out.println(username);
}

@Test(enabled=false)

public void MobileSignin()
{
	System.out.println("Mobile signin");
}

@BeforeSuite
public void bfsuite()
{
	System.out.println("I am 1st");
}
@BeforeMethod
public void bfMethod()
{
	System.out.println("I am before method will excute at start of every method in day3");
}

@AfterMethod
public void AfMethod()
{
	System.out.println("I am after method will excute at end of every method in day3");
}
@Test

public void MobileSignout()
{
	System.out.println("Mobile Signout");
}

@Test(dependsOnMethods= {"webLoginCarLoan"})

public void loginAPICarLoan()
{
	System.out.println("RestAPI carloan");
}

}
