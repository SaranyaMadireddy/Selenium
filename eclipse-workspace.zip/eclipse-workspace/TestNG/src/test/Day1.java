package test;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class Day1 {

	@AfterTest
	public void LastExecution()
	{
		System.out.println("I will execute Last");
	}
	
	@AfterSuite
	public void LastSuite()
	{
		System.out.println("I am Last");
	}
	
	
	
	@Test
	public void Demo()
	{
		System.out.println("Test");
		Assert.assertTrue(false);
	}
	
	@Test(groups= {"Smoke"})
	public void SecondTest()
	{
		System.out.println("Hello");
	}

}
