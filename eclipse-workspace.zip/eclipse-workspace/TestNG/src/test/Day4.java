package test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Day4 {
	
@Test

public void webLoginHomeLoan()
{
	System.out.println("login Homeloan");
}
@BeforeClass
public void bfclass()
{
	System.out.println("I am before class I will execute before all methods");
}

@AfterClass
public void AFclass()
{
	System.out.println("I am after class I will execute after all methods");
}

@Test(groups= {"Smoke"})

public void MobileLoginHomeLoan()
{
	System.out.println("Mobile Homeloan");
}

@Test(dataProvider="getData")

public void loginAPIHomeLoan(String username,String password)
{
	System.out.println("RestAPI Homeloan");
	System.out.println(username);
	
	System.out.println(password);
}

@DataProvider
public Object[][] getData()
{
	//1st Data -username ,password -good credit history
	//2nd Data -username ,password -no credit history
	//3rd Data -username ,password -fraud history
	
	Object[][] data=new Object[3][2];
	
	//1st set
	data[0][0]="firstusername";
	data[0][1]="rules1";
	
	//2nd set
	data[1][0]="secondusername";
	data[1][1]="rules2";
	
	//3rd set
	data[2][0]="thirdusername";
	data[2][1]="rules3";
	
	return data;
	
	
}


}
