package learning;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;

public class SeleniumIntro {

	public static void main(String[] args) {
		
		//Invoking chrome browser
		//chrome -chromedriver extern->Methods close get
		//firefox -FirefoxDriver ->Methods close get
		//safari safariDriver ->Methods close get
		// Webdriver close get
		//WedDriver Methods+Class Methods
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\c45182\\OneDrive - Cox Communications\\Documents\\chromedriver-win64 (1)\\chromedriver-win64");
		WebDriver driver=new ChromeDriver();
		
	driver.get("www.google.com");

	}

}
